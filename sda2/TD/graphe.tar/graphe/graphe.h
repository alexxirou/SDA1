// TD4 Graphes par liste d'adjacence  

#include "stdlib.h"
#include "memory.h"
#include "stdio.h"
#include <stdbool.h>

/******************************************/
/*
// graphe.h
*/

#ifndef __GRAPHE_H__
#define __GRAPHE_H__

typedef unsigned S;
typedef unsigned Nat;

#define OMEGA 0

typedef struct strarc {
	S v;
	struct strarc *suc;
} Strarc, *ListeSom;

typedef struct {
	S v;
	ListeSom ls;
} Couple; 

typedef struct strsom {
	Couple c;
	struct strsom *suiv;
} Strsom, *Graphe;

// Operations internes sur liste de sommets ListeSom
ListeSom _nouvls();
ListeSom _adjtetels(ListeSom l, S x);
ListeSom _rechls(ListeSom l,  S x);
int _rangls(ListeSom l, S x);
ListeSom _supkiemels(ListeSom l, Nat k);
S _kiemels(ListeSom l, Nat k);
bool _videls(ListeSom l);
Nat _longueur(ListeSom l);
void _destroyls(ListeSom l);

// Operations internes sur listes de couples
Strsom *_nouvlsom();
Strsom *_adjtetelsom(Strsom * l, S x);
Strsom * _rechlsom(Strsom * l, S x);
int _ranglsom(Strsom * l, S x);
Strsom * _supkiemelsom(Strsom * l, Nat k);
S _kiemelsom(Strsom * l, Nat k);
bool _videlsom(Strsom * l);
Nat _longueurlsom(Strsom * l);
void _destroylsom(Strsom * l);

// Operations sur le graphe
//////////////////////////////////////////////////

// pr� : vrai
// post : retourne le graphe vide
// modif : aucune
Graphe graphe_nouv();
// pr� : x n�est pas d�j� un sommet du graphe (!graphe_exs(g,x))
// post : retourne le graphe g auquel le sommet x est ajout�
// modif : le graphe g est modifi� par effet de bord
Graphe graphe_adjs(Graphe g, S x);
// pr� : u et v sont des sommets du graphe g et (u,v) n�en est pas une ar�te
// post : retourne le graphe g auquel l�arc (u,v) a �t� ajout�
// modif : le graphe g est modifi� par effet de bord
Graphe graphe_adja(Graphe g, S u, S v);
// pr� : x est un sommet du graphe d dans lequel il n�y a aucun arc d�extr�mit� x
// post : retourne le graphe g dans lequel le sommet s a �t� supprim�
// modif : le graphe g est modifi� par effet de bord
Graphe graphe_sups(Graphe g, S x);
// pr� : (u, v) est un arc du graphe
// post : retourne le graphe g duquel l�arc (u,v) a �t� supprim�
// modif : le graphe g est modifi� par effet de bord
Graphe graphe_supa(Graphe g, S u, S v);
// pr� : vrai
// post : teste l�existende du sommet x dans g
// modif : aucune
bool graphe_exs(Graphe g, S x);
// pr� : vrai
// post : teste l�existence de l�arc (u,v)
// modif : aucune
bool graphe_exa(Graphe g, S u, S v);
// pr� : vrai
// post : retourne le degr� ext�rieur de x dans g
// modif : aucune
Nat graphe_de(Graphe g, S x);
// pr� : vrai
// post : retourne le degr� int�rieur de x dans g
// modif : aucune
Nat graphe_di(Graphe g, S x);
// pr� : vrai
// post : lib�re toute la m�moire
// modif : le graphe g n'existe plus
void graphe_free(Graphe g);

// Operations sur les ensembles de successeurs et predecesseurs
///////////////////////////////////////////////////////////////
// pr� : x est un sommet de g
// post : retourne la liste des successeurs de x dans g, cette liste est independente du graphe
// modif : aucune
ListeSom graphe_lsuccs(Graphe g, S x);
// pr� : x est un sommet de g
// post : retourne la liste des pr�decessurs de x dans g, cette liste est independente du graphe
// modif : aucune
ListeSom graphe_lpreds(Graphe g, S x);

#endif






